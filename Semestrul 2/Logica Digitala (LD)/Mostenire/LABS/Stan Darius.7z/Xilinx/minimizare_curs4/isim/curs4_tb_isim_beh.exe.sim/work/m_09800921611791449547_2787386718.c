/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/stan/Desktop/Xilinx/minimizare_curs4/curs4.v";



static void Cont_11_0(char *t0)
{
    char t3[8];
    char t23[8];
    char t54[8];
    char t73[8];
    char t105[8];
    char t126[8];
    char t157[8];
    char t185[8];
    char t206[8];
    char t237[8];
    char *t1;
    char *t2;
    char *t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    char *t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    int t46;
    int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t55;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    char *t63;
    char *t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    char *t79;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    unsigned int t86;
    char *t87;
    char *t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    int t97;
    int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t106;
    char *t107;
    unsigned int t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    char *t113;
    char *t114;
    char *t115;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    char *t124;
    char *t125;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    char *t130;
    char *t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    char *t139;
    char *t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    int t149;
    int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    char *t161;
    char *t162;
    char *t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    char *t171;
    char *t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    char *t186;
    char *t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    char *t193;
    char *t194;
    char *t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    char *t204;
    char *t205;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    char *t210;
    char *t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    char *t219;
    char *t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    int t229;
    int t230;
    unsigned int t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t238;
    unsigned int t239;
    unsigned int t240;
    char *t241;
    char *t242;
    char *t243;
    unsigned int t244;
    unsigned int t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    char *t251;
    char *t252;
    unsigned int t253;
    unsigned int t254;
    unsigned int t255;
    int t256;
    unsigned int t257;
    unsigned int t258;
    unsigned int t259;
    int t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    char *t265;
    char *t266;
    char *t267;
    char *t268;
    char *t269;
    unsigned int t270;
    unsigned int t271;
    char *t272;
    unsigned int t273;
    unsigned int t274;
    char *t275;
    unsigned int t276;
    unsigned int t277;
    char *t278;

LAB0:    t1 = (t0 + 2840U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(11, ng0);
    t2 = (t0 + 1048U);
    t4 = *((char **)t2);
    memset(t3, 0, 8);
    t2 = (t4 + 4);
    t5 = *((unsigned int *)t2);
    t6 = (~(t5));
    t7 = *((unsigned int *)t4);
    t8 = (t7 & t6);
    t9 = (t8 & 1U);
    if (t9 != 0)
        goto LAB7;

LAB5:    if (*((unsigned int *)t2) == 0)
        goto LAB4;

LAB6:    t10 = (t3 + 4);
    *((unsigned int *)t3) = 1;
    *((unsigned int *)t10) = 1;

LAB7:    t11 = (t3 + 4);
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = (~(t13));
    *((unsigned int *)t3) = t14;
    *((unsigned int *)t11) = 0;
    if (*((unsigned int *)t12) != 0)
        goto LAB9;

LAB8:    t19 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t19 & 1U);
    t20 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t20 & 1U);
    t21 = (t0 + 1208U);
    t22 = *((char **)t21);
    t24 = *((unsigned int *)t3);
    t25 = *((unsigned int *)t22);
    t26 = (t24 & t25);
    *((unsigned int *)t23) = t26;
    t21 = (t3 + 4);
    t27 = (t22 + 4);
    t28 = (t23 + 4);
    t29 = *((unsigned int *)t21);
    t30 = *((unsigned int *)t27);
    t31 = (t29 | t30);
    *((unsigned int *)t28) = t31;
    t32 = *((unsigned int *)t28);
    t33 = (t32 != 0);
    if (t33 == 1)
        goto LAB10;

LAB11:
LAB12:    t55 = (t0 + 1528U);
    t56 = *((char **)t55);
    memset(t54, 0, 8);
    t55 = (t56 + 4);
    t57 = *((unsigned int *)t55);
    t58 = (~(t57));
    t59 = *((unsigned int *)t56);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB16;

LAB14:    if (*((unsigned int *)t55) == 0)
        goto LAB13;

LAB15:    t62 = (t54 + 4);
    *((unsigned int *)t54) = 1;
    *((unsigned int *)t62) = 1;

LAB16:    t63 = (t54 + 4);
    t64 = (t56 + 4);
    t65 = *((unsigned int *)t56);
    t66 = (~(t65));
    *((unsigned int *)t54) = t66;
    *((unsigned int *)t63) = 0;
    if (*((unsigned int *)t64) != 0)
        goto LAB18;

LAB17:    t71 = *((unsigned int *)t54);
    *((unsigned int *)t54) = (t71 & 1U);
    t72 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t72 & 1U);
    t74 = *((unsigned int *)t23);
    t75 = *((unsigned int *)t54);
    t76 = (t74 & t75);
    *((unsigned int *)t73) = t76;
    t77 = (t23 + 4);
    t78 = (t54 + 4);
    t79 = (t73 + 4);
    t80 = *((unsigned int *)t77);
    t81 = *((unsigned int *)t78);
    t82 = (t80 | t81);
    *((unsigned int *)t79) = t82;
    t83 = *((unsigned int *)t79);
    t84 = (t83 != 0);
    if (t84 == 1)
        goto LAB19;

LAB20:
LAB21:    t106 = (t0 + 1208U);
    t107 = *((char **)t106);
    memset(t105, 0, 8);
    t106 = (t107 + 4);
    t108 = *((unsigned int *)t106);
    t109 = (~(t108));
    t110 = *((unsigned int *)t107);
    t111 = (t110 & t109);
    t112 = (t111 & 1U);
    if (t112 != 0)
        goto LAB25;

LAB23:    if (*((unsigned int *)t106) == 0)
        goto LAB22;

LAB24:    t113 = (t105 + 4);
    *((unsigned int *)t105) = 1;
    *((unsigned int *)t113) = 1;

LAB25:    t114 = (t105 + 4);
    t115 = (t107 + 4);
    t116 = *((unsigned int *)t107);
    t117 = (~(t116));
    *((unsigned int *)t105) = t117;
    *((unsigned int *)t114) = 0;
    if (*((unsigned int *)t115) != 0)
        goto LAB27;

LAB26:    t122 = *((unsigned int *)t105);
    *((unsigned int *)t105) = (t122 & 1U);
    t123 = *((unsigned int *)t114);
    *((unsigned int *)t114) = (t123 & 1U);
    t124 = (t0 + 1528U);
    t125 = *((char **)t124);
    t127 = *((unsigned int *)t105);
    t128 = *((unsigned int *)t125);
    t129 = (t127 & t128);
    *((unsigned int *)t126) = t129;
    t124 = (t105 + 4);
    t130 = (t125 + 4);
    t131 = (t126 + 4);
    t132 = *((unsigned int *)t124);
    t133 = *((unsigned int *)t130);
    t134 = (t132 | t133);
    *((unsigned int *)t131) = t134;
    t135 = *((unsigned int *)t131);
    t136 = (t135 != 0);
    if (t136 == 1)
        goto LAB28;

LAB29:
LAB30:    t158 = *((unsigned int *)t73);
    t159 = *((unsigned int *)t126);
    t160 = (t158 | t159);
    *((unsigned int *)t157) = t160;
    t161 = (t73 + 4);
    t162 = (t126 + 4);
    t163 = (t157 + 4);
    t164 = *((unsigned int *)t161);
    t165 = *((unsigned int *)t162);
    t166 = (t164 | t165);
    *((unsigned int *)t163) = t166;
    t167 = *((unsigned int *)t163);
    t168 = (t167 != 0);
    if (t168 == 1)
        goto LAB31;

LAB32:
LAB33:    t186 = (t0 + 1368U);
    t187 = *((char **)t186);
    memset(t185, 0, 8);
    t186 = (t187 + 4);
    t188 = *((unsigned int *)t186);
    t189 = (~(t188));
    t190 = *((unsigned int *)t187);
    t191 = (t190 & t189);
    t192 = (t191 & 1U);
    if (t192 != 0)
        goto LAB37;

LAB35:    if (*((unsigned int *)t186) == 0)
        goto LAB34;

LAB36:    t193 = (t185 + 4);
    *((unsigned int *)t185) = 1;
    *((unsigned int *)t193) = 1;

LAB37:    t194 = (t185 + 4);
    t195 = (t187 + 4);
    t196 = *((unsigned int *)t187);
    t197 = (~(t196));
    *((unsigned int *)t185) = t197;
    *((unsigned int *)t194) = 0;
    if (*((unsigned int *)t195) != 0)
        goto LAB39;

LAB38:    t202 = *((unsigned int *)t185);
    *((unsigned int *)t185) = (t202 & 1U);
    t203 = *((unsigned int *)t194);
    *((unsigned int *)t194) = (t203 & 1U);
    t204 = (t0 + 1528U);
    t205 = *((char **)t204);
    t207 = *((unsigned int *)t185);
    t208 = *((unsigned int *)t205);
    t209 = (t207 & t208);
    *((unsigned int *)t206) = t209;
    t204 = (t185 + 4);
    t210 = (t205 + 4);
    t211 = (t206 + 4);
    t212 = *((unsigned int *)t204);
    t213 = *((unsigned int *)t210);
    t214 = (t212 | t213);
    *((unsigned int *)t211) = t214;
    t215 = *((unsigned int *)t211);
    t216 = (t215 != 0);
    if (t216 == 1)
        goto LAB40;

LAB41:
LAB42:    t238 = *((unsigned int *)t157);
    t239 = *((unsigned int *)t206);
    t240 = (t238 | t239);
    *((unsigned int *)t237) = t240;
    t241 = (t157 + 4);
    t242 = (t206 + 4);
    t243 = (t237 + 4);
    t244 = *((unsigned int *)t241);
    t245 = *((unsigned int *)t242);
    t246 = (t244 | t245);
    *((unsigned int *)t243) = t246;
    t247 = *((unsigned int *)t243);
    t248 = (t247 != 0);
    if (t248 == 1)
        goto LAB43;

LAB44:
LAB45:    t265 = (t0 + 3240);
    t266 = (t265 + 56U);
    t267 = *((char **)t266);
    t268 = (t267 + 56U);
    t269 = *((char **)t268);
    memset(t269, 0, 8);
    t270 = 1U;
    t271 = t270;
    t272 = (t237 + 4);
    t273 = *((unsigned int *)t237);
    t270 = (t270 & t273);
    t274 = *((unsigned int *)t272);
    t271 = (t271 & t274);
    t275 = (t269 + 4);
    t276 = *((unsigned int *)t269);
    *((unsigned int *)t269) = (t276 | t270);
    t277 = *((unsigned int *)t275);
    *((unsigned int *)t275) = (t277 | t271);
    xsi_driver_vfirst_trans(t265, 0, 0);
    t278 = (t0 + 3160);
    *((int *)t278) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t3) = 1;
    goto LAB7;

LAB9:    t15 = *((unsigned int *)t3);
    t16 = *((unsigned int *)t12);
    *((unsigned int *)t3) = (t15 | t16);
    t17 = *((unsigned int *)t11);
    t18 = *((unsigned int *)t12);
    *((unsigned int *)t11) = (t17 | t18);
    goto LAB8;

LAB10:    t34 = *((unsigned int *)t23);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t23) = (t34 | t35);
    t36 = (t3 + 4);
    t37 = (t22 + 4);
    t38 = *((unsigned int *)t3);
    t39 = (~(t38));
    t40 = *((unsigned int *)t36);
    t41 = (~(t40));
    t42 = *((unsigned int *)t22);
    t43 = (~(t42));
    t44 = *((unsigned int *)t37);
    t45 = (~(t44));
    t46 = (t39 & t41);
    t47 = (t43 & t45);
    t48 = (~(t46));
    t49 = (~(t47));
    t50 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t50 & t48);
    t51 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t51 & t49);
    t52 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t52 & t48);
    t53 = *((unsigned int *)t23);
    *((unsigned int *)t23) = (t53 & t49);
    goto LAB12;

LAB13:    *((unsigned int *)t54) = 1;
    goto LAB16;

LAB18:    t67 = *((unsigned int *)t54);
    t68 = *((unsigned int *)t64);
    *((unsigned int *)t54) = (t67 | t68);
    t69 = *((unsigned int *)t63);
    t70 = *((unsigned int *)t64);
    *((unsigned int *)t63) = (t69 | t70);
    goto LAB17;

LAB19:    t85 = *((unsigned int *)t73);
    t86 = *((unsigned int *)t79);
    *((unsigned int *)t73) = (t85 | t86);
    t87 = (t23 + 4);
    t88 = (t54 + 4);
    t89 = *((unsigned int *)t23);
    t90 = (~(t89));
    t91 = *((unsigned int *)t87);
    t92 = (~(t91));
    t93 = *((unsigned int *)t54);
    t94 = (~(t93));
    t95 = *((unsigned int *)t88);
    t96 = (~(t95));
    t97 = (t90 & t92);
    t98 = (t94 & t96);
    t99 = (~(t97));
    t100 = (~(t98));
    t101 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t101 & t99);
    t102 = *((unsigned int *)t79);
    *((unsigned int *)t79) = (t102 & t100);
    t103 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t103 & t99);
    t104 = *((unsigned int *)t73);
    *((unsigned int *)t73) = (t104 & t100);
    goto LAB21;

LAB22:    *((unsigned int *)t105) = 1;
    goto LAB25;

LAB27:    t118 = *((unsigned int *)t105);
    t119 = *((unsigned int *)t115);
    *((unsigned int *)t105) = (t118 | t119);
    t120 = *((unsigned int *)t114);
    t121 = *((unsigned int *)t115);
    *((unsigned int *)t114) = (t120 | t121);
    goto LAB26;

LAB28:    t137 = *((unsigned int *)t126);
    t138 = *((unsigned int *)t131);
    *((unsigned int *)t126) = (t137 | t138);
    t139 = (t105 + 4);
    t140 = (t125 + 4);
    t141 = *((unsigned int *)t105);
    t142 = (~(t141));
    t143 = *((unsigned int *)t139);
    t144 = (~(t143));
    t145 = *((unsigned int *)t125);
    t146 = (~(t145));
    t147 = *((unsigned int *)t140);
    t148 = (~(t147));
    t149 = (t142 & t144);
    t150 = (t146 & t148);
    t151 = (~(t149));
    t152 = (~(t150));
    t153 = *((unsigned int *)t131);
    *((unsigned int *)t131) = (t153 & t151);
    t154 = *((unsigned int *)t131);
    *((unsigned int *)t131) = (t154 & t152);
    t155 = *((unsigned int *)t126);
    *((unsigned int *)t126) = (t155 & t151);
    t156 = *((unsigned int *)t126);
    *((unsigned int *)t126) = (t156 & t152);
    goto LAB30;

LAB31:    t169 = *((unsigned int *)t157);
    t170 = *((unsigned int *)t163);
    *((unsigned int *)t157) = (t169 | t170);
    t171 = (t73 + 4);
    t172 = (t126 + 4);
    t173 = *((unsigned int *)t171);
    t174 = (~(t173));
    t175 = *((unsigned int *)t73);
    t176 = (t175 & t174);
    t177 = *((unsigned int *)t172);
    t178 = (~(t177));
    t179 = *((unsigned int *)t126);
    t180 = (t179 & t178);
    t181 = (~(t176));
    t182 = (~(t180));
    t183 = *((unsigned int *)t163);
    *((unsigned int *)t163) = (t183 & t181);
    t184 = *((unsigned int *)t163);
    *((unsigned int *)t163) = (t184 & t182);
    goto LAB33;

LAB34:    *((unsigned int *)t185) = 1;
    goto LAB37;

LAB39:    t198 = *((unsigned int *)t185);
    t199 = *((unsigned int *)t195);
    *((unsigned int *)t185) = (t198 | t199);
    t200 = *((unsigned int *)t194);
    t201 = *((unsigned int *)t195);
    *((unsigned int *)t194) = (t200 | t201);
    goto LAB38;

LAB40:    t217 = *((unsigned int *)t206);
    t218 = *((unsigned int *)t211);
    *((unsigned int *)t206) = (t217 | t218);
    t219 = (t185 + 4);
    t220 = (t205 + 4);
    t221 = *((unsigned int *)t185);
    t222 = (~(t221));
    t223 = *((unsigned int *)t219);
    t224 = (~(t223));
    t225 = *((unsigned int *)t205);
    t226 = (~(t225));
    t227 = *((unsigned int *)t220);
    t228 = (~(t227));
    t229 = (t222 & t224);
    t230 = (t226 & t228);
    t231 = (~(t229));
    t232 = (~(t230));
    t233 = *((unsigned int *)t211);
    *((unsigned int *)t211) = (t233 & t231);
    t234 = *((unsigned int *)t211);
    *((unsigned int *)t211) = (t234 & t232);
    t235 = *((unsigned int *)t206);
    *((unsigned int *)t206) = (t235 & t231);
    t236 = *((unsigned int *)t206);
    *((unsigned int *)t206) = (t236 & t232);
    goto LAB42;

LAB43:    t249 = *((unsigned int *)t237);
    t250 = *((unsigned int *)t243);
    *((unsigned int *)t237) = (t249 | t250);
    t251 = (t157 + 4);
    t252 = (t206 + 4);
    t253 = *((unsigned int *)t251);
    t254 = (~(t253));
    t255 = *((unsigned int *)t157);
    t256 = (t255 & t254);
    t257 = *((unsigned int *)t252);
    t258 = (~(t257));
    t259 = *((unsigned int *)t206);
    t260 = (t259 & t258);
    t261 = (~(t256));
    t262 = (~(t260));
    t263 = *((unsigned int *)t243);
    *((unsigned int *)t243) = (t263 & t261);
    t264 = *((unsigned int *)t243);
    *((unsigned int *)t243) = (t264 & t262);
    goto LAB45;

}


extern void work_m_09800921611791449547_2787386718_init()
{
	static char *pe[] = {(void *)Cont_11_0};
	xsi_register_didat("work_m_09800921611791449547_2787386718", "isim/curs4_tb_isim_beh.exe.sim/work/m_09800921611791449547_2787386718.didat");
	xsi_register_executes(pe);
}
